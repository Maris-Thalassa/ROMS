function version(self)

% Version of 10-Aug-2001 14:37:19.

% svn $Id$
%=======================================================================
% Copyright (C) 2000 Dr. Charles R. Denham, ZYDECO.
%  All Rights Reserved.
%   Disclosure without explicit written consent from the
%    copyright owner does not constitute publication.
%=======================================================================

helpdlg(help(mfilename), 'seagrid')
