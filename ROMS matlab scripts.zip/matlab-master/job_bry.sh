#
t2sub -q S -N MAT-Y1_15_1 -l mem=50gb -l walltime=24:00:00 -et 1 -p 0 -W group_list=t2gnakamulab ./run_bry.sh
#t2sub -q S -N MAT-Y1 -l mem=10gb -l walltime=01:00:00 -et 1 -p 0 -W group_list=t2gnakamulab ./run_matlab.sh
